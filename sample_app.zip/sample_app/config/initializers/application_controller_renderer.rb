# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9832476b291e8ba821ce6e026fbc3b0834be83f5cf8a3bc4e3a187f705b6f9fcced5486cf0de07181da76f11204b6369c53de34e4efa36ed32779221e5033bb1'